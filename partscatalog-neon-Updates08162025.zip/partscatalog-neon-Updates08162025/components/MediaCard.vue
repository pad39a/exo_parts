<script setup>

</script>

<template>
    <Card>
        <slot name="header"></slot>
        <p>
            <slot name="content"></slot>
        </p>
    </Card>
</template>